// src/router/index.js

import { createRouter, createWebHistory } from 'vue-router';
import Home from '@/components/KIM_Pages/StartPage.vue';
import Lobby from '@/components/KIM_Pages/LobbyPage.vue';
import Play from '@/components/KIM_Pages/PlayPage.vue';
import Impressum from '@/components/ImpressumView.vue';
import About from '@/components/KIM_Pages/AboutView.vue';
import Wait from '@/components/KIM_Pages/WaitPage.vue';
import Instructions from '@/components/KIM_Pages/InstructionsPage.vue';
import LoginPage from '@/components/KIM_Pages/LoginPage.vue';

// Funktion, um Authentifizierungsstatus zu prüfen
function isAuthenticated() {
  return !!localStorage.getItem('authToken'); // Beispiel mit einem Token im localStorage
}

const routes = [

  {
    path: '/',
    name: 'home',
    component: Home,
    meta: { authRequired: true },
  },
  {
    path: '/',
    name: 'lobby',
    component: Lobby,
    meta: { authRequired: true },
  },
  {
    path: '/',
    name: 'play',
    component: Play,
    meta: { authRequired: true },
  },
  {
    path: '/',
    name: 'impressum',
    component: Impressum,
  },
  {
    path: '/',
    name: 'about',
    component: About,
  },
  {
    path: '/',
    name: 'wait',
    component: Wait,
    meta: { authRequired: true },
  },
  {
    path: '/',
    name: 'instruction',
    component: Instructions,
  }
  ,
  {
    path: '/login',
    name: 'login',
    component: LoginPage,
  }
];

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes,
});

// Globaler Navigation Guard
// router.beforeEach((to, from, next) => {
//   // Wenn die Route Authentifizierung erfordert
//   if (to.meta.authRequired && !isAuthenticated()) {
//     next({ name: 'login' }); // Weiterleitung zur Login-Seite
//   } else {
//     next(); // Erlaubt den Zugriff
//   }
// });

export default router;
