import BaseDialog from "@/components/UI/BaseDialog.vue";
export default {
  components: {
    BaseDialog,
  },
  name: "login",
  data() {
    return {
      email: "",
      password: "",
      loginError: false, // Zeigt Fehlernachricht bei falschem Login an
    };
  },
  methods: {
    /**
     * Prüft Login-Daten und führt bei Erfolg eine Weiterleitung durch.
     */
    handleRegister() {
      if (this.email && this.password) {
        // Simulierte Login-Logik (Beispiel)
        if (this.email === "admin" && this.password === "password") {
          // Authentifizierung erfolgreich
          this.saveAuthToken("exampleToken"); // Authentifizierungs-Token speichern
          this.$router.push({ name: "home" }); // Weiterleitung zur Startseite
        } else {
          this.loginError = true; // Login-Fehler anzeigen
        }
      } else {
        this.loginError = true; // Fehler, wenn Felder leer sind
      }
    },

    /**
     * Prüft Login-Daten und führt bei Erfolg eine Weiterleitung durch.
     */
    handleLogin() {
      if (this.email && this.password) {
        // Simulierte Login-Logik (Beispiel)
        if (this.email === "admin" && this.password === "password") {
          // Authentifizierung erfolgreich
          this.saveAuthToken("exampleToken"); // Authentifizierungs-Token speichern
          this.$router.push({ name: "home" }); // Weiterleitung zur Startseite
        } else {
          this.loginError = true; // Login-Fehler anzeigen
        }
      } else {
        this.loginError = true; // Fehler, wenn Felder leer sind
      }
    },

    /**
     * Speichert das Authentifizierungs-Token (z. B. im LocalStorage).
     * @param {string} token - Das Authentifizierungs-Token
     */
    saveAuthToken(token) {
      localStorage.setItem("authToken", token);
    },

    /**
     * Überprüft, ob der Benutzer bereits eingeloggt ist.
     * Wenn ja, wird er zur Startseite weitergeleitet.
     */
    checkAlreadyLoggedIn() {
      const token = localStorage.getItem("authToken");
      if (token) {
        this.$router.push({ name: "home" }); // Weiterleitung zur Startseite
      }
    },
  },
  created() {
    // Prüft beim Laden der Seite, ob der Benutzer bereits eingeloggt ist
    this.checkAlreadyLoggedIn();
  },
};
