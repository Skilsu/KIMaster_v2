const express = require("express");
const mysql = require("mysql2");
const dotenv = require("dotenv");

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3001;

// MySQL-Verbindung erstellen
const db = mysql.createConnection({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
});

db.connect((err) => {
  if (err) {
    console.error("Fehler bei der Verbindung zur Datenbank:", err);
    process.exit(1);
  }
  console.log("Mit der MySQL-Datenbank verbunden.");
});

// Middleware
app.use(express.json());

// Beispielroute
app.get("/api/users", (req, res) => {
  db.query("SELECT * FROM users", (err, results) => {
    if (err) return res.status(500).json({ error: "Fehler bei der Datenbankabfrage" });
    res.json(results);
  });
});

app.listen(PORT, () => {
  console.log(`Backend läuft auf Port ${PORT}`);
});
